To install and run the rest-api example use the folling steps:

1. copy index.js and package.json in a directory
2. under the directory run `npm install` to install the depndencies
3. run the server with `node index.js`
